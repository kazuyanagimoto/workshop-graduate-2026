tar_analysis <- tar_plan(
  tab_balance = summarize_did(did),
  tar_file(
    tab_balance_file,
    tabular_balance(
      tab_balance,
      here_rel("output", "table", "tab_balance.tex")
    )
  ),
  tar_file(
    fig_trends_file,
    plot_trends(did, here_rel("output", "img", "fig_trends.pdf"))
  ),
  models_did = estimate_did(did),
  tar_file(
    tab_did_file,
    tabular_did(models_did, here_rel("output", "table", "tab_did.tex"))
  ),
  model_event = estimate_event(did),
  tar_file(
    fig_event_file,
    plot_event(model_event, here_rel("output", "img", "fig_event.pdf"))
  )
)

summarize_did <- function(did) {
  did |>
    summarize(
      n_obs = n(),
      n_unit = n_distinct(id),
      mean_y = mean(y),
      mean_x1 = mean(x1),
      .by = c(group, post)
    ) |>
    arrange(desc(group), post)
}

tabular_balance <- function(tab_balance, path) {
  tab_balance |>
    mutate(post = if_else(post == 1, "Post", "Pre")) |>
    setNames(c("Group", "Period", "Obs.", "Units", "Mean $y$", "Mean $x_1$")) |>
    tt() |>
    format_tt(digits = 3, num_fmt = "decimal") |>
    theme_latex(environment_table = FALSE) |>
    save_tt(path, overwrite = TRUE)
  path
}

plot_trends <- function(did, path) {
  cutoff <- min(did$period[did$post == 1]) - 0.5

  p <- did |>
    summarize(mean_y = mean(y), .by = c(period, group)) |>
    ggplot(aes(x = period, y = mean_y, color = group,
               linetype = group, shape = group)) +
    geom_vline(xintercept = cutoff, linetype = "dotted", color = "grey40") +
    geom_line() +
    geom_point(size = 2) +
    scale_x_continuous(breaks = seq_len(max(did$period))) +
    labs(x = "Period", y = "Mean outcome",
         color = NULL, linetype = NULL, shape = NULL) +
    theme_classic(base_size = 11) +
    theme(legend.position = "inside",
          legend.position.inside = c(0.15, 0.85))

  ggsave(path, p, width = 6, height = 3.5)
  path
}

estimate_did <- function(did) {
  list(
    "(1)" = feols(y ~ post * treat, data = did, vcov = "hetero"),
    "(2)" = feols(y ~ post * treat + x1, data = did, vcov = "hetero"),
    "(3)" = feols(y ~ i(post, treat, ref = 0) | id + period,
                  data = did, vcov = ~id),
    "(4)" = feols(y ~ x1 + i(post, treat, ref = 0) | id + period,
                  data = did, vcov = ~id)
  )
}

tabular_did <- function(models_did, path) {
  tab <- modelsummary(
    models_did,
    output = "tinytable",
    escape = FALSE,
    coef_map = c(
      "post:treat" = "Post $\\times$ Treated",
      "post::1:treat" = "Post $\\times$ Treated",
      "post" = "Post",
      "treat" = "Treated",
      "x1" = "$x_1$"
    ),
    gof_map = c("nobs", "r.squared", "FE: id", "FE: period"),
    stars = c("*" = 0.1, "**" = 0.05, "***" = 0.01)
  )

  tab |>
    theme_latex(environment_table = FALSE) |>
    save_tt(path, overwrite = TRUE)
  path
}

estimate_event <- function(did) {
  feols(y ~ x1 + i(rel_period, treat, ref = -1) | id + period,
        data = did, vcov = ~id)
}

plot_event <- function(model_event, path) {
  p <- ggfixest::ggiplot(model_event, geom_style = "pointrange") +
    labs(x = "Periods since treatment", y = "Estimate", title = NULL) +
    theme_classic(base_size = 11) +
    theme(legend.position = "none")

  ggsave(path, p, width = 6, height = 3.5)
  path
}
