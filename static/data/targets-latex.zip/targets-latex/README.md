# targets + LaTeX パイプラインのサンプル

`{targets}` で生データの読み込みから LaTeX 論文の PDF コンパイルまでを1本につないだ最小の例です. 教科書の「LaTeX + `{targets}` のワークフロー」の節と同じ構成になっています.

分析の中身は `fixest` に同梱されている疑似パネルデータ `base_did` の差の差分析です. 記述統計の表, 群ごとの推移の図, 4列の回帰表, イベントスタディの図を作り, それらを `manuscript/main.tex` から読み込んで PDF にします.

## 前提

次の R パッケージを使います. 入っていないものがあれば, 先にインストールしてください.

```r
install.packages(c(
  "targets", "tarchetypes", "fixest", "modelsummary", "tinytable",
  "ggfixest", "withr", "fs", "here", "readr", "dplyr", "ggplot2", "tinytex"
))
```

LaTeX のコンパイルには TinyTeX を使います. まだ入れていなければ `tinytex::install_tinytex()` を一度実行してください. 足りない LaTeX パッケージは, 初回のコンパイル時に自動でインストールされます.

## 動かす

このフォルダを作業ディレクトリにして, R から次を実行します.

```r
targets::tar_visnetwork()   # 依存関係を見る (実行前なので全部 Outdated)
targets::tar_make()         # 生データから PDF まで一気に作る
```

13個のターゲットが順に計算され, 最後に `manuscript/main.pdf` (3ページ) ができます. 途中の成果物は次の場所です.

```
output/table/tab_balance.tex   記述統計の表
output/table/tab_did.tex       回帰表
output/img/fig_trends.pdf      群ごとの平均アウトカムの推移
output/img/fig_event.pdf       イベントスタディ
```

## 試してみるとよいこと

`R/tar_data.R` の `clean_did()` に, たとえば外れ値を落とす行を足してみてください.

```r
    ) |>
    filter(abs(x1) < 8)
```

そのうえで `targets::tar_make()` を実行すると `9 completed, 4 skipped` になります. スキップされるのは生データのファイルとその読み込み, `main.tex`, `references.bib` の4つで, クリーニングから下流の図表はすべて作り直され, PDF も再コンパイルされます. `targets::tar_visnetwork()` を挟むと, どこが古くなっているかを実行前に確認できます.

元に戻すには足した行を消してもう一度 `tar_make()` を実行します.

## つまずきやすい点

表は `tinytable` の既定の `tabularray` 形式で書き出しているので, `manuscript/main.tex` のプリアンブルで `xcolor` と `tabularray` を読み込んでいます. `fontenc` (T1) と `lmodern` は, pdfLaTeX で回帰表の注記の `<` を正しく出すためのものです.

`R/tar_manuscript.R` の `compile_manuscript()` には, `tinytex::pdflatex()` が `.tex` のあるディレクトリに移動しないことへの対処を, 理由と一緒にコメントで書いてあります.
