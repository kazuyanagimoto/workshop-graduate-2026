# tar_quarto() reads the tar_load() and tar_read() calls in the code chunks of
# main.qmd and makes the targets named there dependencies of the manuscript,
# so the PDF is rendered again whenever any of them changes. It does not pick
# up the bibliography, which is therefore tracked through extra_files.
tar_manuscript <- tar_plan(
  tar_quarto(
    manuscript,
    "manuscript/main.qmd",
    extra_files = "manuscript/references.bib"
  )
)
