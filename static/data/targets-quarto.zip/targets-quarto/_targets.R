library(targets)
library(tarchetypes)

tar_option_set(
  packages = c("dplyr", "fixest")
)

tar_source()

tar_plan(
  tar_data,
  tar_analysis,
  tar_manuscript
)
