tar_manuscript <- tar_plan(
  tar_file(main_tex_file, here_rel("manuscript", "main.tex")),
  tar_file(bib_file, here_rel("manuscript", "references.bib")),
  tar_file(
    manuscript_pdf_file,
    compile_manuscript(
      main_tex_file,
      bib_file,
      tab_balance_file,
      tab_did_file,
      fig_trends_file,
      fig_event_file
    )
  )
)

# Everything after main_tex_file is unused inside the function. The arguments
# are listed so that targets records the tables and figures as dependencies of
# the PDF, and recompiles whenever any of them changes.
compile_manuscript <- function(main_tex_file, ...) {
  # pdflatex() runs in the current directory, not in the directory holding the
  # .tex file. Move there first, so that the relative paths written in main.tex
  # are the ones a co-author gets when compiling manuscript/main.tex by hand.
  withr::with_dir(
    fs::path_dir(main_tex_file),
    tinytex::pdflatex(fs::path_file(main_tex_file))
  )
  fs::path_ext_set(main_tex_file, "pdf")
}
