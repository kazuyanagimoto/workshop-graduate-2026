# targets + Quarto パイプラインのサンプル

`{targets}` で生データの読み込みから Quarto 論文の PDF レンダリングまでを1本につないだ最小の例です. 教科書の「Quarto + `{targets}` のワークフロー」の節と同じ構成になっています.

分析の中身は, `fixest` に同梱されている疑似パネルデータ `base_did` の差の差分析です. パイプラインは集計表と推定結果を R のオブジェクトとして作るところまでを受け持ちます. `manuscript/main.qmd` はそれを `tar_load()` で読み込み, 記述統計の表, 群ごとの推移の図, 4列の回帰表, イベントスタディの図を自分で作って PDF にします. 本文中の数値も, 読み込んだ結果からインラインコードで埋め込んでいます.

## 前提

次の R パッケージを使います. 入っていないものがあれば, 先にインストールしてください.

```r
install.packages(c(
  "targets", "tarchetypes", "fixest", "modelsummary", "tinytable",
  "ggfixest", "here", "readr", "dplyr", "ggplot2", "quarto", "rmarkdown"
))
```

R のパッケージとは別に, [Quarto](https://quarto.org/docs/get-started/) 本体が必要です. PDF は Quarto に同梱されている Typst で組むので, LaTeX は要りません. Quarto 1.10 で動作を確認しています.

## 動かす

このフォルダを作業ディレクトリにして, R から次を実行します.

```r
targets::tar_visnetwork()   # 依存関係を見る (実行前なので全部 Outdated)
targets::tar_make()         # 生データから PDF まで一気に作る
```

8個のターゲットが順に計算され, 最後に `manuscript/main.pdf` (3ページ) ができます. 図表のファイルはどこにも書き出されません. 図表は `main.qmd` をレンダリングするたびに, その中で作られます.

一度 `tar_make()` を実行したあとは, `manuscript/main.qmd` を RStudio や Positron のプレビュー, あるいはターミナルの `quarto render manuscript/main.qmd` で直接レンダリングしても同じ PDF ができます. 原稿はストア (`_targets/`) から結果を読むだけなので, 計算をやり直すことはありません.

## 試してみるとよいこと

`R/tar_data.R` の `clean_did()` に, たとえば外れ値を落とす行を足してみてください.

```r
    ) |>
    filter(abs(x1) < 8)
```

そのうえで `targets::tar_make()` を実行すると `6 completed, 2 skipped` になります. スキップされるのは生データのファイルとその読み込みの2つで, クリーニングから下流の集計と推定はすべてやり直され, PDF もレンダリングし直されます. `targets::tar_visnetwork()` を挟むと, どこが古くなっているかを実行前に確認できます. 元に戻すには足した行を消してもう一度 `tar_make()` を実行します.

次に, `manuscript/main.qmd` の `theme_set(theme_classic(base_size = 11))` を `theme_set(theme_minimal(base_size = 11))` に変えて `tar_make()` を実行してみてください. 今度は `1 completed, 7 skipped` で, 作り直されるのは PDF だけです. 図の見た目を変えても, 推定はやり直されません.

## つまずきやすい点

`R/tar_manuscript.R` の `tar_quarto()` は, `main.qmd` のコードチャンクにある `tar_load()` と `tar_read()` を読み取って, そこに書かれたターゲットを PDF の依存関係にします. 読み取れるのは, ターゲットの名前をそのまま書いた呼び出しだけです. `source()` で読み込んだ R ファイルの中の `tar_load()` や, `tar_load(starts_with("model"))` のような書き方は依存関係になりません. その場合, 上流が変わっても PDF は古いまま残ります.

`main.qmd` を手でレンダリングすると, コードは `manuscript/` の中で実行されます. どちらから実行してもストアが見つかるように, `tar_load(..., store = here::here("_targets"))` でストアの場所を指定しています. `here::here()` はこのフォルダの `.here` を目印にプロジェクトのルートを見つけるので, `.here` を消さないでください.

Typst では `*` が太字の記号なので, 回帰表の星印はエスケープが必要です. 一方で, 1列目の係数名には `$x_1$` のような数式を入れたいので, 表全体はエスケープできません. そこで `modelsummary(..., escape = FALSE)` としたうえで, 星印の入る列と注だけを `format_tt(escape = TRUE)` でエスケープしています. セルの中の数式は Typst の記法 (`$times$` など) で書きます.
