tar_analysis <- tar_plan(
  tab_balance = summarize_did(did),
  trends = summarize_trends(did),
  models_did = estimate_did(did),
  model_event = estimate_event(did)
)

summarize_did <- function(did) {
  did |>
    summarize(
      n_obs = n(),
      n_unit = n_distinct(id),
      mean_y = mean(y),
      mean_x1 = mean(x1),
      .by = c(group, post)
    ) |>
    arrange(desc(group), post)
}

summarize_trends <- function(did) {
  did |>
    summarize(mean_y = mean(y), .by = c(period, post, group))
}

estimate_did <- function(did) {
  list(
    "(1)" = feols(y ~ post * treat, data = did, vcov = "hetero"),
    "(2)" = feols(y ~ post * treat + x1, data = did, vcov = "hetero"),
    "(3)" = feols(y ~ i(post, treat, ref = 0) | id + period,
                  data = did, vcov = ~id),
    "(4)" = feols(y ~ x1 + i(post, treat, ref = 0) | id + period,
                  data = did, vcov = ~id)
  )
}

estimate_event <- function(did) {
  feols(y ~ x1 + i(rel_period, treat, ref = -1) | id + period,
        data = did, vcov = ~id)
}
